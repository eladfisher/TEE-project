﻿using Intel.Dal;
using System;
using System.Text;
using System.Security.Cryptography;
using System.Net;
using System.Net.Sockets;

namespace project5NewHost
{
    class Program
    {
       static Socket sender;
        private static bool loggedIn = false;

        static void Main(string[] args)
        {
#if AMULET
            // When compiled for Amulet the Jhi.DisableDllValidation flag is set to true 
            // in order to load the JHI.dll without DLL verification.
            // This is done because the JHI.dll is not in the regular JHI installation folder, 
            // and therefore will not be found by the JhiSharp.dll.
            // After disabling the .dll validation, the JHI.dll will be loaded using the Windows search path
            // and not by the JhiSharp.dll (see http://msdn.microsoft.com/en-us/library/7d83bc18(v=vs.100).aspx for 
            // details on the search path that is used by Windows to locate a DLL) 
            // In this case the JHI.dll will be loaded from the $(OutDir) folder (bin\Amulet by default),
            // which is the directory where the executable module for the current process is located.
            // The JHI.dll was placed in the bin\Amulet folder during project build.
            Jhi.DisableDllValidation = true;
#endif

            Jhi jhi = Jhi.Instance;
            JhiSession session;

            // This is the UUID of this Trusted Application (TA).
            //The UUID is the same value as the applet.id field in the Intel(R) DAL Trusted Application manifest.
            string appletID = "954d73e3-6560-471e-9501-db6c70764727";
            // This is the path to the Intel Intel(R) DAL Trusted Application .dalp file that was created by the Intel(R) DAL Eclipse plug-in.
            string appletPath = "C:/eclipse-workspace\\project5New\\bin\\project5New.dalp";

            // Install the Trusted Application
            Console.WriteLine("Installing the applet.");
            jhi.Install(appletID, appletPath);

            // Install the Trusted Application
            Console.WriteLine("Installing the applet.");
            jhi.Install(appletID, appletPath);

            // Start a session with the Trusted Application
            byte[] initBuffer = new byte[] { }; // Data to send to the applet onInit function
            Console.WriteLine("Opening a session.");
            jhi.CreateSession(appletID, JHI_SESSION_FLAGS.None, initBuffer, out session);


            // Send and Receive data to/from the Trusted Application
            byte[] sendBuff = new byte[20]; // A message to send to the TA
            byte[] recvBuff = new byte[260]; // A buffer to hold the output data from the TA
            int responseCode; // The return value that the TA provides using the IntelApplet.setResponseCode method
            byte[] publicKey = new byte[4];
            byte[] publicModulus = new byte[256];
            int EncSeed = 0;
            RSACryptoServiceProvider RSAalg = new RSACryptoServiceProvider();
            RSAParameters PKey = RSAalg.ExportParameters(true);
            SHA256Managed sha256 = new SHA256Managed();


            IPAddress ipAddr = new IPAddress(0x0100007F);
            IPEndPoint localEndPoint = new IPEndPoint(ipAddr, 565);
            sender = new Socket(ipAddr.AddressFamily,
                   SocketType.Stream, ProtocolType.Tcp);
            Console.WriteLine("Connecting to server...");
            sender.Connect(localEndPoint);
            Console.WriteLine("Connected");

            int cmdId = 0; // The ID of the command to be performed by the TA
            do
            {
                recvBuff = new byte[2000];
                Console.WriteLine("1 = Register\n ");
                while (!int.TryParse(Console.ReadLine(), out cmdId)) ;
                if (cmdId > 12 || cmdId < 1) break;
                switch (cmdId)
                {
                    case 1:
                        {

                           

                            String password = Console.ReadLine();
                            while (password.Length > 20) password = Console.ReadLine();
                            sendBuff = UTF32Encoding.UTF8.GetBytes(password);
                            Console.WriteLine(password);
                            Console.WriteLine("Requesting OTP from server: ");
                            recvBuff = new byte[512];
                            //jhi.SendAndRecv2(session, 5, sendBuff, ref recvBuff, out responseCode);
                            recvBuff = new byte[512];
                            //jhi.SendAndRecv2(session, 6, sendBuff, ref recvBuff, out responseCode);
                            EncSeed = getAndPlantSeed(getByteUntilIndex(recvBuff, 4));
                        }
                        break;

                    case 2:
                        {
                            String password = Console.ReadLine();
                            while (password.Length > 20) password = Console.ReadLine();
                            sendBuff = UTF32Encoding.UTF8.GetBytes(password);
                            Console.WriteLine(password);

                            //CheckOTPPassword(password);

                        }
                        break;

                    case 3:
                        {

                        }
                        break;

                    case 4:
                        {
                            String password = Console.ReadLine();
                            while (password.Length > 20) password = Console.ReadLine();
                            sendBuff = UTF32Encoding.UTF8.GetBytes(password);
                            Console.WriteLine(password);
                        }
                        break;
                    //case 5:
                    //    {

                    //    }
                    //    break;
                    //case 6:
                    //    {

                    //    }
                    //    break;
                    //case 7:
                    //    {
                    //        String nonce = Console.ReadLine();

                    //        //while (nonce.Length > 20) nonce = Console.ReadLine();
                    //        //sendBuff = UTF32Encoding.UTF8.GetBytes(nonce);

                    //        HashAlgorithm algorithm = SHA256.Create();
                    //        sendBuff = algorithm.ComputeHash(UTF32Encoding.UTF8.GetBytes(nonce));


                    //        Console.WriteLine(nonce);
                    //    }
                    //    break;

                    case 9:
                        {
                            Console.WriteLine("checking otp from server");

                        }
                        break;
                    

                }
                Console.WriteLine(sendBuff);
                //sendBuff[4] = UTF32Encoding.UTF8.GetBytes(action)[0];
                Console.WriteLine("Performing send and receive operation.");

                jhi.SendAndRecv2(session, cmdId, sendBuff, ref recvBuff, out responseCode);
                switch (responseCode)
                {
                    case -1:
                        {
                            Console.WriteLine("access denied");
                            Console.WriteLine("Response buffer is " + UTF32Encoding.UTF8.GetString(recvBuff));
                        }
                        break;
                    case 1:
                        {
                            //move the seed to the applet
                            
                            Console.WriteLine("enc seed: " + EncSeed);

                            sendBuff = BitConverter.GetBytes(EncSeed);
                            Array.Reverse(sendBuff);
                            Console.WriteLine(sendBuff);

                            
                            jhi.SendAndRecv2(session, 10, sendBuff, ref recvBuff, out responseCode);
                            Console.WriteLine("enc Seed planted");
                        }
                        break;
                    case 2:
                    case 3:
                    case 4:
                        break;
                    /*    case 5:
                    default:
                        {
                            Console.WriteLine("Response buffer is " + UTF32Encoding.UTF8.GetString(recvBuff));
                        }
                        break;
                    case 6:
                        {

                            //publicKey = recvBuff;

                            for (int i = 0; i < 4; ++i)
                            {
                                publicKey[i] = recvBuff[i];
                            }

                            for (int i = 0; i < 256; ++i)
                            {
                                publicModulus[i] = recvBuff[i + 4];
                            }


                            //PKey.Exponent = publicKey;
                            //PKey.Modulus = publicModulus;

                            Console.Write("Public Key is: ");
                            foreach (byte b in publicKey) Console.Write(b);

                            Console.Write("\nPublic modulus is: ");
                            foreach (byte b in publicModulus) { Console.Write(b); Console.Write(" "); }

                            Console.WriteLine("\n");
                        }
                        break;
                    case 7:
                        {


                            byte[] myHash = HashAlgorithm.Create("SHA256").ComputeHash(sendBuff);

                            System.Console.WriteLine(publicModulus.Length);
                            System.Console.WriteLine(publicKey.Length);

                            RSAParameters rsaKeyInfo = new RSAParameters();
                            rsaKeyInfo.Modulus = publicModulus;
                            rsaKeyInfo.Exponent = publicKey;

                            RSA rsa = RSA.Create();
                            rsa.ImportParameters(rsaKeyInfo);
                            RSAPKCS1SignatureDeformatter rsaDeformatter = new RSAPKCS1SignatureDeformatter(rsa);
                            rsaDeformatter.SetHashAlgorithm("SHA256");

                            if (rsaDeformatter.VerifySignature(sendBuff, recvBuff))
                            {
                                Console.WriteLine("The signature is valid.");
                            }
                            else
                            {
                                Console.WriteLine("The signature is not valid.");
                            }

                            Console.Write("Encrypted message is: " + ByteArrayToString(recvBuff));

                            bool Result = RSAalg.VerifyData(sendBuff, SHA256.Create(), recvBuff);
                            if (Result) Console.WriteLine("Match!");
                            //foreach (byte b in recvBuff) Console.Write(b);
                            Console.WriteLine("\n");
                        }
                        */
                    case 9:
                        {

                            byte[] number = new byte[4];

                            number[3] = recvBuff[0];
                            number[2] = recvBuff[1];
                            number[1] = recvBuff[2];
                            number[0] = recvBuff[3];

                            Console.WriteLine(BitConverter.ToUInt32(number, 0).ToString());
                            //Console.WriteLine(BitConverter.ToInt32(number, 0).ToString());
                            //Console.WriteLine(BitConverter.ToInt32(recvBuff, 0).ToString());
                            //Console.WriteLine(BitConverter.ToUInt32(recvBuff, 0).ToString());
                            //Console.WriteLine(BitConverter.ToUInt32(recvBuff, 28).ToString());



                            Console.WriteLine("otp send is: "+(BitConverter.ToUInt32(number, 0) % 1000000).ToString());

                            //foreach(byte b in recvBuff)
                            //{
                            //    Console.Write(b.ToString()+" ");
                            //}

                            CheckOTPPassword((BitConverter.ToUInt32(number, 0) % 1000000).ToString());


                        }
                        break;

                    case 10:
                        {

                        }
                        break;

                }



            } while (true);


            //Console.Out.WriteLine("Response buffer is " + UTF32Encoding.UTF8.Get(recvBuff));



            // Close the session
            Console.WriteLine("Closing the session.");
            jhi.CloseSession(session);

            //Uninstall the Trusted Application
            Console.WriteLine("Uninstalling the applet.");
            jhi.Uninstall(appletID);

            Console.WriteLine("Press Enter to finish.");
            Console.Read();
        }
        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }

        public static bool CheckOTPPassword(String password)
        {

            //String pbkey = "";
            //foreach (byte b in password) { pbkey += b.ToString(); }
            byte[] messageSent = Encoding.ASCII.GetBytes("SIGN IN OTP " + password);
            int byteSent = sender.Send(messageSent);


            // Data buffer
            byte[] messageReceived = new byte[1024];

            // We receive the message using
            // the method Receive(). This
            // method returns number of bytes
            // received, that we'll use to
            // convert them to string
            int byteRecv = sender.Receive(messageReceived);
            string messageRev = Encoding.ASCII.GetString(messageReceived, 0, byteRecv);
            Console.WriteLine("Message from Server -> {0}", messageRev);

            return true;
        }

        public static int GetSeedFromServer(byte[] AppletPublicKey)
        {

            
            //Send message
            String pbkey = "";
            foreach (byte b in AppletPublicKey) { pbkey += b.ToString(); }
            byte[] messageSent = Encoding.ASCII.GetBytes("GET RAND " + pbkey);
            int byteSent = sender.Send(messageSent);


            // Data buffer
            byte[] messageReceived = new byte[1024];

            // We receive the message using
            // the method Receive(). This
            // method returns number of bytes
            // received, that we'll use to
            // convert them to string
            int byteRecv = sender.Receive(messageReceived);
            string messageRev = Encoding.ASCII.GetString(messageReceived, 0, byteRecv);
            Console.WriteLine("Message from Server -> {0}", messageRev);

            int RandNum;
            if (!int.TryParse(Encoding.ASCII.GetString(messageReceived, 0, byteRecv), out RandNum))
            {
                return -1;
            }
            return RandNum;
        }
        private static int getAndPlantSeed(byte[] AppletPublicKey)
        {
            return GetSeedFromServer(AppletPublicKey);
        }
        private static byte[] joinByte(byte[] a, byte[] b)
        {
            byte[] newArray = new byte[a.Length + b.Length];
            for (int i = 0; i < a.Length; i++)
            {
                newArray[i] = a[i];
            }
            for (int i = 0; i < b.Length; i++)
            {
                newArray[i + a.Length] = b[i];
            }
            return newArray;
        }

        private static byte[] getByteFromIndex(byte[] a, int index)
        {
            byte[] newArray = new byte[a.Length - index];
            for (int i = 0; i < a.Length - index; i++)
            {
                newArray[i] = a[i + index];
            }

            return newArray;
        }

        private static byte[] getByteUntilIndex(byte[] a, int index)
        {
            byte[] newArray = new byte[index];
            for (int i = 0; i < index; i++)
            {
                newArray[i] = a[i];
            }

            return newArray;
        }

        private static byte[] getByteUntilIndex(byte[] a, int indexFirst,int indexSecond)
        {
            int len = indexSecond - indexFirst;
            byte[] newArray = new byte[len];
            for (int i = 0; i < len; i++)
            {
                newArray[i] = a[indexFirst + i];
            }

            return newArray;
        }
    }
}