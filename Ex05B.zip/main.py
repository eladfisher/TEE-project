
# TO DO: import modules
import socket
import random
# TO DO: set constants
IP = '0.0.0.0'
PORT = 565
SOCKET_TIMEOUT = 0.1
RAND_REQ = "GET RAND"
ERROR = "-1".encode()
APPLET_PUBLIC_KEY ="";

def main():
    # Open a socket and loop forever while waiting for clients
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((IP, PORT))
    server_socket.listen()
    print("Listening for connections on port {}".format(PORT))

    while True:
        client_socket, client_address = server_socket.accept()
        print('New connection received')
        client_socket.settimeout(SOCKET_TIMEOUT)
        try:
            handle_client(client_socket)
        except:
            continue


def get_client_data(client_socket):
    return client_socket.recv(1024).decode()


def handle_client(client_socket):
    while True:
        try:
            client_req_data = get_client_data(client_socket)
            client_req = client_req_data.split(" ")
        except socket.timeout:
            continue
        if client_req[0] + ' ' + client_req[1] == RAND_REQ and len(client_req) == 3:
            APPLET_PUBLIC_KEY = client_req[2];
            print(APPLET_PUBLIC_KEY)
            x = random.randint(0, 9999999999)
        else:
            client_socket.send("ERROR".encode())
            return -1
        client_socket.send(str(x).zfill(10).encode())
        print("sent " + str(x))



if __name__ == "__main__":
    # Call the main handler function
    main()