package project5New;

import com.intel.util.*;
import com.intel.crypto.*;
import com.intel.crypto.HashAlg;

//
// Implementation of DAL Trusted Application: project5New 
//
// **************************************************************************************************
// NOTE:  This default Trusted Application implementation is intended for DAL API Level 7 and above
// **************************************************************************************************

public class project5New extends IntelApplet {

RsaAlg rsa=null; 
	
	boolean LoggedIn = false;
	
	/**
	 * This method will be called by the VM when a new session is opened to the Trusted Application 
	 * and this Trusted Application instance is being created to handle the new session.
	 * This method cannot provide response data and therefore calling
	 * setResponse or setResponseCode methods from it will throw a NullPointerException.
	 * 
	 * @param	request	the input data sent to the Trusted Application during session creation
	 * 
	 * @return	APPLET_SUCCESS if the operation was processed successfully, 
	 * 		any other error status code otherwise (note that all error codes will be
	 * 		treated similarly by the VM by sending "cancel" error code to the SW application).
	 */
	public int onInit(byte[] request) {
		DebugPrint.printString("Hello, DAL!");
		
		if(FlashStorage.getFlashDataSize(0) != 0) {
			
			FlashStorage.eraseFlashData(0);
		}
		
		return APPLET_SUCCESS;
		
	}
	
	
	
	/*
	  FlashStorage.writeFlashData(0, request, 0, request.length);
			final byte[] myResponse = { 'O', 'K' };
			setResponse(myResponse, 0, myResponse.length);
	 */
	
	/**
	 * This method will be called by the VM to handle a command sent to this
	 * Trusted Application instance.
	 * 
	 * @param	commandId	the command ID (Trusted Application specific) 
	 * @param	request		the input data for this command 
	 * @return	the return value should not be used by the applet
	 */
	public int invokeCommand(int commandId, byte[] request) {
		// 1 = Register, 2 = Login, 3 = GetRandom, 4 = ResetPassword
		
		DebugPrint.printString("Received command Id: " + commandId + ".");
		if(request != null)
		{
			DebugPrint.printString("Received buffer:");
			DebugPrint.printBuffer(request);
		}
		
		
		
		switch(commandId) {
		case 1://create user
		{
			
			if(FlashStorage.getFlashDataSize(0) != 0) {
				final byte[] myResponse = { 'F', 'a', 'i', 'l', 'e', 'd' };
				commandId = -1;
				setResponse(myResponse, 0, myResponse.length);
				break;
			}

			byte[] length = { (byte)(request.length) };
			DebugPrint.printString("Calculating connected data array:");
			byte[] CData = new byte[request.length + 1];
			for(int i = 0; i< request.length; i++) {
				CData[i] = request[i];
			}
			CData[request.length] = length[0];
			DebugPrint.printBuffer(CData);
			DebugPrint.printString("writing Data and length array:");
			FlashStorage.writeFlashData(0, CData, 0, request.length + 1);
			final byte[] myResponse = { 'O', 'K' };
			
			
			//byte[] ExistingData = null;
			
			DebugPrint.printBuffer(myResponse);
			DebugPrint.printString("Responding");
			setResponse(myResponse, 0, myResponse.length);
		}
			break;
			
		case 2: //log in
		{
			byte[] ExistingData = new byte[21];
			DebugPrint.printString("Reading Flash");
			DebugPrint.printInt(FlashStorage.getFlashDataSize(0));
			FlashStorage.readFlashData(0, ExistingData , 0);
			int length = ExistingData[FlashStorage.getFlashDataSize(0)-1];
				DebugPrint.printBuffer(request);
				DebugPrint.printInt(request.length);
				DebugPrint.printInt(length);
			DebugPrint.printString("start comparing");
			if(request.length != length) {
				DebugPrint.printString("wrong password");
				final byte[] myResponse = { 'F', 'a', 'i', 'l', 'e', 'd' };
				commandId = -1;
				setResponse(myResponse, 0, myResponse.length);
				break;
			}
				
			
			for(int i = 0; i < request.length ; i++) 
			{
				if(ExistingData[i] != request[i]) {
					DebugPrint.printString("wrong password");
					final byte[] myResponse = { 'F', 'a', 'i', 'l', 'e', 'd' };
					commandId = -1;
					DebugPrint.printString("set resp");
					setResponse(myResponse, 0, myResponse.length);
					DebugPrint.printString("set resp done");
					break;
				}
			}
			DebugPrint.printString("comparing done");
			if(commandId != -1) 
			{
				DebugPrint.printString("login success");
				LoggedIn = true;
				final byte[] myResponse = { 'O', 'K' };
				setResponse(myResponse, 0, myResponse.length);
			}
		}
			break;
		case 3://get random number
		{
			
			if(!checkLogin()) {
				
				commandId = -1;
				break;
			}
			
			String b = String.valueOf(Math.abs( Calendar.getMillisFromStartup() * Calendar.getMillisFromStartup() * Calendar.getMillisFromStartup()));
			DebugPrint.printString(b);
			final byte[] myResponse = new byte[b.length()];
			for(int i = 0; i < b.length(); i++) {
				myResponse[i] = (byte)b.charAt(i);
			}
			DebugPrint.printBuffer(myResponse);
			DebugPrint.printString("Responding");
			setResponse(myResponse, 0, myResponse.length);
			
		}
			break;
		case 4://reset password
		{
			
			if( ResetPassword(request, LoggedIn)) {
				final byte[] myResponse = { 'O', 'K' };
				DebugPrint.printBuffer(myResponse);
				DebugPrint.printString("Responding");
				setResponse(myResponse, 0, myResponse.length);
			}else {
				final byte[] myResponse = { 'F', 'a', 'i', 'l', 'e', 'd' };
				commandId = -1;
				DebugPrint.printBuffer(myResponse);
				DebugPrint.printString("Responding");
				setResponse(myResponse, 0, myResponse.length);
			}
			LoggedIn = false;
		}
		case 5://generate keys
		{
			if(!checkLogin() && false) {
				
				commandId = -1;
				break;
			}
			
			 rsa = RsaAlg.create();
			
			if(FlashStorage.getFlashDataSize(1)!=0)//key exists
			{
				DebugPrint.printString("Data Existing In flash 1");
				
				byte [] keys = new byte[516];
				FlashStorage.readFlashData(1, keys, 0);
				DebugPrint.printString("Key: ");
				DebugPrint.printBuffer(keys);
				final byte[] privateKey = new byte[256];
				final byte[] publicKey = new byte[4];
				final byte[] modulu = new byte[256]; 
				DebugPrint.printString("finished reading flash 1");
				DebugPrint.printString("copying keys to buffer");
				
				
				
				for(int i = 0; i < 256; i++) {
					privateKey[i] = keys[i];
				}
				
				for(int i = 0; i < 4; i++) {
					publicKey[i] = keys[i+256];
				}
				for(int i = 0; i < 256; i++) {
					modulu[i] = keys[i + 260];
				}
				
				DebugPrint.printString("finished copying keys to buffer");
				
				DebugPrint.printString("modulu:");
				DebugPrint.printBuffer(modulu);
				DebugPrint.printString("public:");
				DebugPrint.printBuffer(publicKey);
				DebugPrint.printString("private:");
				DebugPrint.printBuffer(privateKey);
				
				DebugPrint.printString("setting key:");
				try {
					rsa.setKey(modulu, (short) 0 , (short)modulu.length, publicKey,(short)0, (short)4, privateKey, (short)0, (short)privateKey.length);
					
				}catch (Exception ex) {
					DebugPrint.printString("message: " + ex.getMessage() + "\n");
					DebugPrint.printString(ex.toString());
				}
				DebugPrint.printString("Key was set");
				
				
			}
			
			else {
				
				
				byte [] keys = new byte[516];
				
				rsa.generateKeys((short) 256);
				DebugPrint.printString("keys generated");
				DebugPrint.printInt(rsa.getModulusSize());
				DebugPrint.printInt(rsa.getPublicExponentSize());
				DebugPrint.printInt(rsa.getPrivateExponentSize());
				
				final byte[] privateKey = new byte[rsa.getPrivateExponentSize()];
				final byte[] publicKey = new byte[4];
				final byte[] module = new byte[rsa.getModulusSize()];
				DebugPrint.printString("Getting Key:");
				try {
					rsa.getKey(module, (short)0, publicKey,(short) 0, privateKey,(short) 0);
					
				}catch(Exception ex) {
					DebugPrint.printString(ex.toString());
				}
				
				
				DebugPrint.printBuffer(module);
				DebugPrint.printString("Public:");
				DebugPrint.printBuffer(publicKey);
				DebugPrint.printString("Private:");
				DebugPrint.printBuffer(privateKey);
				
				for(int i = 0; i < 256; i++) {
					keys[i] = privateKey[i];
				}
				
				for(int i = 0; i < 4; i++) {
					keys[256+i] = publicKey[i];
				}
				
				for(int i = 0; i < 256; i++) {
					keys[260+i] = module[i];
				}
				
				DebugPrint.printBuffer(keys);
				FlashStorage.writeFlashData(1, keys, 0, 516);
				DebugPrint.printString("finish writing");
			}
			rsa.setHashAlg(RsaAlg.HASH_TYPE_SHA256);
			rsa.setPaddingScheme(RsaAlg.PAD_TYPE_PKCS1);
			final byte[] myResponse = { 'O', 'K' };
			DebugPrint.printBuffer(myResponse);
			DebugPrint.printString("Responding");
			setResponse(myResponse, 0, myResponse.length);
		}
		break;
		
		case 6:
		{
			if(!checkLogin() && false) {
				
				commandId = -1;
				break;
			}

			if(rsa==null) {
				final byte[] myResponse = { 'F', 'a', 'i', 'l', 'e', 'd' };
				DebugPrint.printBuffer(myResponse);
				DebugPrint.printString("Responding");
				setResponse(myResponse, 0, myResponse.length);
				commandId = -1;
				break;
			}
			
			byte [] publicKey = new byte[4];
			byte [] keys = new byte[516];
			DebugPrint.printString("reading Keys:");
			FlashStorage.readFlashData(1, keys, 0);
			DebugPrint.printString("Copying public:");
			
			byte[] answer = new byte [260];
			
			for(int i = 0; i < 4; i++) {
				answer[i] = keys[256+i];
			}
			
			
			for(int i = 0; i < 256; i++) {
				answer[i+4] = keys[260+i];
			}
			
//			DebugPrint.printString("Module ints:");
//			
//			for(int i = 0; i < 256; i++) {
//				DebugPrint.printInt(answer[i+4]);
//			}
//			
//			DebugPrint.printString("key ints:");
//			
//			for(int i = 0; i < 260; i++) {
//				DebugPrint.printInt(answer[i]);
//			}
			
			DebugPrint.printString("Sending public Key:");
			DebugPrint.printBuffer(answer);
			setResponse(answer, 0, answer.length);
			DebugPrint.printString("Sent");
		}
			break;
		case 7://sign data
		{
			if(!checkLogin()) {
				
				commandId = -1;
				break;
			}

			if(rsa==null) {
				final byte[] myResponse = { 'F', 'a', 'i', 'l', 'e', 'd' };
				DebugPrint.printBuffer(myResponse);
				DebugPrint.printString("Responding");
				setResponse(myResponse, 0, myResponse.length);
				commandId = -1;
				break;
			}
			
			byte[] encryptedMsg = new byte[256]; 
			DebugPrint.printString("Encrypting");
			
			
			try {
				rsa.signHash(request, (short)0, (short)request.length, encryptedMsg, (short)0);				
			}catch(Exception ex) {
				DebugPrint.printString(ex.toString());
			}
			DebugPrint.printString("Responding");
			setResponse(encryptedMsg, 0, encryptedMsg.length);
			
		}
			break;
		case 8: {
			DebugPrint.printString("Data Existing In flash 1");
			
			byte [] keys = new byte[516];
			FlashStorage.readFlashData(1, keys, 0);
			DebugPrint.printString("Key: ");
			DebugPrint.printBuffer(keys);
			final byte[] privateKey = new byte[256];
			final byte[] publicKey = new byte[4];
			final byte[] modulu = new byte[256]; 
			DebugPrint.printString("finished reading flash 1");
			DebugPrint.printString("copying keys to buffer");
			
			
			
			for(int i = 0; i < 256; i++) {
				privateKey[i] = keys[i];
			}
			
			for(int i = 0; i < 4; i++) {
				publicKey[i] = keys[i+256];
			}
			for(int i = 0; i < 256; i++) {
				modulu[i] = keys[i + 260];
			}
			
			DebugPrint.printString("finished copying keys to buffer");
			
			DebugPrint.printString("modulu:");
			DebugPrint.printBuffer(modulu);
			DebugPrint.printString("public:");
			DebugPrint.printBuffer(publicKey);
			DebugPrint.printString("private:");
			DebugPrint.printBuffer(privateKey);
			
			DebugPrint.printString("Responding");
			setResponse(publicKey, 0, publicKey.length);
		}
		break;
		
		case 9:
		{
			Hash hash = HashAlg.create(HashAlg.HASH_TYPE_SHA256);
			byte [] seedAndCounter = new byte [FlashStorage.getFlashDataSize(1)];
			int counter;
			
			FlashStorage.readFlashData(1, seedAndCounter, 0);
			
			byte [] seed = new byte [seedAndCounter.length-4];
			byte [] counterArr = new byte [4];
			
			counterArr[0] = seedAndCounter[FlashStorage.getFlashDataSize(1)-1];
			counterArr[1] = seedAndCounter[FlashStorage.getFlashDataSize(1)-2];
			counterArr[2] = seedAndCounter[FlashStorage.getFlashDataSize(1)-3];
			counterArr[3] = seedAndCounter[FlashStorage.getFlashDataSize(1)-4];
			
			
			counter = convertByteArrayToInt2(counterArr);
			
			
			DebugPrint.printString("clac otp number");
			DebugPrint.printInt(counter);
			DebugPrint.printString("buffer seed:" + seedAndCounter.length);
			DebugPrint.printBuffer(seedAndCounter);
			
			byte [] output = new byte[32];
			int length = hash.processComplete(seedAndCounter, (short)0, (short)seedAndCounter.length, output, (short)0);
			
			DebugPrint.printInt(length);
			
			DebugPrint.printString("otp calculated");
			DebugPrint.printBuffer(output);
			setResponse(output,0,output.length);
			
			
			counter++;
			byte [] index = convertIntToByteArray2(counter); 
			//DebugPrint.printBuffer(request);
			
			
			
			seedAndCounter[request.length] = index[0];
			seedAndCounter[request.length+1] = index[1];
			seedAndCounter[request.length+2] = index[2];
			seedAndCounter[request.length+3] = index[3];
			DebugPrint.printBuffer(seedAndCounter);
			DebugPrint.printString("saving seed:");
			
			FlashStorage.writeFlashData(1, seedAndCounter, 0, seedAndCounter.length);
			DebugPrint.printString("seed saved");
			
			
		}break;
		
		case 10:
		{
			byte index = 0; 
			DebugPrint.printBuffer(request);
			
			byte [] seedAndCounter  = new byte[request.length+4];
			
			int i = 0;
			for(byte b : request) {
				seedAndCounter[i++] = b;
			}
			
			seedAndCounter[request.length] = index;
			seedAndCounter[request.length+1] = index;
			seedAndCounter[request.length+2] = index;
			seedAndCounter[request.length+3] = index;
			DebugPrint.printBuffer(seedAndCounter);
			DebugPrint.printString("saving seed:");
			
			FlashStorage.writeFlashData(1, seedAndCounter, 0, seedAndCounter.length);
			DebugPrint.printString("seed saved");
			

		}
		break;
		default:
			break;
		}
		

		/*
		 * To return the response data to the command, call the setResponse
		 * method before returning from this method. 
		 * Note that calling this method more than once will 
		 * reset the response data previously set.
		 */
		

		/*
		 * In order to provide a return value for the command, which will be
		 * delivered to the SW application communicating with the Trusted Application,
		 * setResponseCode method should be called. 
		 * Note that calling this method more than once will reset the code previously set. 
		 * If not set, the default response code that will be returned to SW application is 0.
		 */
		DebugPrint.printString("set resp code");
		setResponseCode(commandId);
		DebugPrint.printString("set resp code done");
		/*
		 * The return value of the invokeCommand method is not guaranteed to be
		 * delivered to the SW application, and therefore should not be used for
		 * this purpose. Trusted Application is expected to return APPLET_SUCCESS code 
		 * from this method and use the setResposeCode method instead.
		 */
		return APPLET_SUCCESS;
	}

	public boolean checkLogin() {
		if(!LoggedIn) {
			final byte[] myResponse = { 'F', 'a', 'i', 'l', 'e', 'd' };
			DebugPrint.printBuffer(myResponse);
			DebugPrint.printString("Responding");
			setResponse(myResponse, 0, myResponse.length);
			return false;
		}
		return true;
		
	}
	
	public static int convertByteArrayToInt2(byte[] bytes) {
        return ((bytes[0] & 0xFF) << 24) |
                ((bytes[1] & 0xFF) << 16) |
                ((bytes[2] & 0xFF) << 8) |
                ((bytes[3] & 0xFF) << 0);
    }
	
	public static int calculate(char ac, int num1, int num2) {
        switch(ac) {
        case '+':
        	return num1 + num2;
		case '-':
        	return num1 - num2;
        	
        case '*':
        	return num1 * num2;
        	
        case '/':
        	return num1 / num2;
        }
        return -1;
    }
	
	public static byte[] convertIntToByteArray2(int value) {
        return new byte[] {
                (byte)value,
                (byte)(value >> 8),
                (byte)(value >> 16),
                (byte)(value >> 24)};
    }
	
	
	public static boolean ResetPassword(byte[] request, boolean loginStatus) {
		{
			if(!loginStatus) return false;
			if(FlashStorage.getFlashDataSize(0) != 0) {
				
				FlashStorage.eraseFlashData(0);
			}else {
				return false;
			}
			if(FlashStorage.getFlashDataSize(1) != 0) {
				
				FlashStorage.eraseFlashData(1);
			}
			

			byte[] length = { (byte)(request.length) };
			DebugPrint.printString("Calculating connected data array:");
			byte[] CData = new byte[request.length + 1];
			for(int i = 0; i< request.length; i++) {
				CData[i] = request[i];
			}
			CData[request.length] = length[0];
			DebugPrint.printBuffer(CData);
			DebugPrint.printString("writing Data and length array:");
			FlashStorage.writeFlashData(0, CData, 0, request.length + 1);
			final byte[] myResponse = { 'O', 'K' };
			return true;
		}
	}

	/**
	 * This method will be called by the VM when the session being handled by
	 * this Trusted Application instance is being closed 
	 * and this Trusted Application instance is about to be removed.
	 * This method cannot provide response data and therefore
	 * calling setResponse or setResponseCode methods from it will throw a NullPointerException.
	 * 
	 * @return APPLET_SUCCESS code (the status code is not used by the VM).
	 */
	public int onClose() {
		DebugPrint.printString("Goodbye, DAL!");
		return APPLET_SUCCESS;
	}
}
